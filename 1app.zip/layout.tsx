import type React from "react"
import type { Metadata } from "next"
import { DM_Sans, Space_Grotesk } from "next/font/google"
import "./globals.css"

const dmSans = DM_Sans({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-dm-sans",
})

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-space-grotesk",
})

export const metadata: Metadata = {
  title: "Board Exam Prep - Your Ultimate Study Companion",
  description:
    "Comprehensive board exam preparation with practice questions, detailed answers, and student discussions. Find questions by class, subject, year, and exam board.",
  keywords:
    "board exam, preparation, practice questions, study guide, exam answers, student discussion, CBSE, ICSE, state board, class 10, class 12",
  authors: [{ name: "Board Exam Prep Team" }],
  generator: "Next.js",
  robots: "index, follow",
  openGraph: {
    title: "Board Exam Prep - Your Ultimate Study Companion",
    description:
      "Comprehensive board exam preparation with practice questions, detailed answers, and student discussions.",
    type: "website",
    url: "https://boardexamprep.com",
    siteName: "Board Exam Prep",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Board Exam Prep - Study Platform",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Board Exam Prep - Your Ultimate Study Companion",
    description:
      "Comprehensive board exam preparation with practice questions, detailed answers, and student discussions.",
    images: ["/og-image.png"],
  },
  verification: {
    google: "your-google-verification-code",
  },
  alternates: {
    canonical: "https://boardexamprep.com",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${dmSans.variable} ${spaceGrotesk.variable} antialiased`}>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "EducationalOrganization",
              name: "Board Exam Prep",
              description: "Comprehensive board exam preparation platform",
              url: "https://boardexamprep.com",
              sameAs: ["https://twitter.com/boardexamprep", "https://facebook.com/boardexamprep"],
              offers: {
                "@type": "Offer",
                category: "Education",
                availability: "https://schema.org/InStock",
                price: "0",
                priceCurrency: "USD",
              },
            }),
          }}
        />
      </head>
      <body>{children}</body>
    </html>
  )
}
