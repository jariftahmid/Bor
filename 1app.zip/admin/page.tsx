import { Navigation } from "@/components/navigation"
import { AdminSidebar } from "@/components/admin-sidebar"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { BookOpen, Users, MessageSquare, TrendingUp, Plus, Eye, AlertTriangle, CheckCircle } from "lucide-react"

const stats = [
  {
    title: "Total Questions",
    value: "1,234",
    change: "+12%",
    changeType: "positive" as const,
    icon: BookOpen,
  },
  {
    title: "Active Students",
    value: "5,678",
    change: "+8%",
    changeType: "positive" as const,
    icon: Users,
  },
  {
    title: "Comments Today",
    value: "89",
    change: "+15%",
    changeType: "positive" as const,
    icon: MessageSquare,
  },
  {
    title: "Success Rate",
    value: "94.5%",
    change: "+2%",
    changeType: "positive" as const,
    icon: TrendingUp,
  },
]

const recentQuestions = [
  {
    id: 1,
    title: "Solve the quadratic equation: x² - 5x + 6 = 0",
    subject: "Mathematics",
    class: "10",
    status: "published",
    views: 156,
    comments: 12,
    createdAt: "2024-01-15",
  },
  {
    id: 2,
    title: "Explain Newton's three laws of motion",
    subject: "Physics",
    class: "11",
    status: "draft",
    views: 0,
    comments: 0,
    createdAt: "2024-01-14",
  },
  {
    id: 3,
    title: "Describe the process of photosynthesis",
    subject: "Biology",
    class: "10",
    status: "published",
    views: 89,
    comments: 8,
    createdAt: "2024-01-13",
  },
]

const pendingComments = [
  {
    id: 1,
    user: "Alex Chen",
    content: "I think there might be an error in step 3 of the solution...",
    questionTitle: "Quadratic Equations",
    flagged: true,
    createdAt: "2 hours ago",
  },
  {
    id: 2,
    user: "Sarah Johnson",
    content: "Could you provide more examples for this concept?",
    questionTitle: "Newton's Laws",
    flagged: false,
    createdAt: "4 hours ago",
  },
]

export default function AdminDashboard() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="flex">
        <AdminSidebar />
        <main className="flex-1 p-8">
          <div className="max-w-7xl mx-auto space-y-8">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-serif font-bold text-foreground">Admin Dashboard</h1>
                <p className="text-muted-foreground">Manage your educational content and monitor platform activity</p>
              </div>
              <div className="flex items-center gap-3">
                <Button variant="outline">
                  <Eye className="h-4 w-4 mr-2" />
                  View Site
                </Button>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Question
                </Button>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat) => {
                const Icon = stat.icon
                return (
                  <Card key={stat.title}>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
                      <Icon className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{stat.value}</div>
                      <p className="text-xs text-muted-foreground">
                        <span className={stat.changeType === "positive" ? "text-green-600" : "text-red-600"}>
                          {stat.change}
                        </span>{" "}
                        from last month
                      </p>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
              {/* Recent Questions */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Recent Questions</CardTitle>
                    <Button variant="outline" size="sm">
                      View All
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentQuestions.map((question) => (
                      <div key={question.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="space-y-1">
                          <h4 className="font-medium text-sm leading-tight">{question.title}</h4>
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary" className="text-xs">
                              {question.subject}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              Class {question.class}
                            </Badge>
                            <Badge
                              variant={question.status === "published" ? "default" : "secondary"}
                              className="text-xs"
                            >
                              {question.status}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>{question.views} views</span>
                            <span>{question.comments} comments</span>
                            <span>{question.createdAt}</span>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm">
                          Edit
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Pending Comments */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Comments Moderation</CardTitle>
                    <Button variant="outline" size="sm">
                      View All
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {pendingComments.map((comment) => (
                      <div key={comment.id} className="p-3 border rounded-lg space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm">{comment.user}</span>
                            {comment.flagged && (
                              <Badge variant="destructive" className="text-xs">
                                <AlertTriangle className="h-3 w-3 mr-1" />
                                Flagged
                              </Badge>
                            )}
                          </div>
                          <span className="text-xs text-muted-foreground">{comment.createdAt}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">{comment.content}</p>
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">on "{comment.questionTitle}"</span>
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Approve
                            </Button>
                            <Button variant="destructive" size="sm">
                              Remove
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
