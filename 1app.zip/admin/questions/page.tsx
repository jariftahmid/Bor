import { AdminSidebar } from "@/components/admin-sidebar"
import { Navigation } from "@/components/navigation"
import { QuestionManagement } from "@/components/question-management"

export default function AdminQuestionsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="flex">
        <AdminSidebar />
        <main className="flex-1 p-8">
          <QuestionManagement />
        </main>
      </div>
    </div>
  )
}
