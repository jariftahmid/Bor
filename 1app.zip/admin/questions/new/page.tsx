import { AdminSidebar } from "@/components/admin-sidebar"
import { Navigation } from "@/components/navigation"
import { QuestionForm } from "@/components/question-form"

export default function NewQuestionPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="flex">
        <AdminSidebar />
        <main className="flex-1 p-8">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-serif font-bold text-foreground">Create New Question</h1>
              <p className="text-muted-foreground">Add a new practice question with detailed solution</p>
            </div>
            <QuestionForm />
          </div>
        </main>
      </div>
    </div>
  )
}
