import type { Metadata } from "next"
import { Navigation } from "@/components/navigation"
import { HeroSection } from "@/components/hero-section"
import { ClassSubjectSelector } from "@/components/class-subject-selector"
import { SearchSection } from "@/components/search-section"
import { FeaturedQuestions } from "@/components/featured-questions"
import { StatsSection } from "@/components/stats-section"

export const metadata: Metadata = {
  title: "Board Exam Prep - Your Ultimate Study Companion",
  description:
    "Comprehensive board exam preparation with practice questions, detailed answers, and student discussions. Find questions by class, subject, year, and exam board.",
}

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main>
        <HeroSection />
        <ClassSubjectSelector />
        <SearchSection />
        <StatsSection />
        <FeaturedQuestions />
      </main>
    </div>
  )
}
