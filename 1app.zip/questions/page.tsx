import { Suspense } from "react"
import { Navigation } from "@/components/navigation"
import { QuestionsSearch } from "@/components/questions-search"
import { QuestionsResults } from "@/components/questions-results"
import { QuestionsFilters } from "@/components/questions-filters"

export const metadata = {
  title: "Practice Questions - Board Exam Prep",
  description: "Search and filter through thousands of board exam questions with detailed answers and solutions.",
}

export default function QuestionsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-2">Practice Questions</h1>
            <p className="text-lg text-muted-foreground">
              Search through thousands of board exam questions with detailed solutions
            </p>
          </div>

          <div className="grid lg:grid-cols-4 gap-8">
            {/* Filters Sidebar */}
            <div className="lg:col-span-1">
              <Suspense fallback={<div>Loading filters...</div>}>
                <QuestionsFilters />
              </Suspense>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3 space-y-6">
              <Suspense fallback={<div>Loading search...</div>}>
                <QuestionsSearch />
              </Suspense>
              <Suspense fallback={<div>Loading questions...</div>}>
                <QuestionsResults />
              </Suspense>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
