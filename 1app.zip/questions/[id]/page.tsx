import { Suspense } from "react"
import { notFound } from "next/navigation"
import type { Metadata } from "next"
import { Navigation } from "@/components/navigation"
import { QuestionDetail } from "@/components/question-detail"
import { QuestionAnswer } from "@/components/question-answer"
import { QuestionActions } from "@/components/question-actions"
import { RelatedQuestions } from "@/components/related-questions"
import { CommentSection } from "@/components/comment-section"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"

// Mock data - in real app this would come from database
const mockQuestion = {
  id: 1,
  title: "Solve the quadratic equation: x² - 5x + 6 = 0",
  question_text: `Solve the quadratic equation: x² - 5x + 6 = 0. 

Show all steps clearly and verify your answer by substituting back into the original equation.

**Additional Requirements:**
- Use the factoring method
- Show the verification step
- Explain each step of the solution`,
  subject: "Mathematics",
  class_level: "10",
  exam_board: "CBSE",
  exam_year: 2023,
  difficulty_level: "medium",
  marks: 3,
  created_at: "2024-01-15T10:00:00Z",
  updated_at: "2024-01-15T10:00:00Z",
  is_published: true,
  tags: ["Algebra", "Quadratic Equations", "Factoring"],
  answer: {
    id: 1,
    answer_text: `**Solution:**

**Step 1: Identify the quadratic equation**
Given equation: x² - 5x + 6 = 0

**Step 2: Factor the quadratic expression**
We need to find two numbers that:
- Multiply to give +6 (the constant term)
- Add to give -5 (the coefficient of x)

The numbers are -2 and -3 because:
- (-2) × (-3) = +6 ✓
- (-2) + (-3) = -5 ✓

**Step 3: Write in factored form**
x² - 5x + 6 = (x - 2)(x - 3) = 0

**Step 4: Apply the zero product property**
If (x - 2)(x - 3) = 0, then either:
- x - 2 = 0  →  x = 2
- x - 3 = 0  →  x = 3

**Step 5: Verification**
Let's verify both solutions:

For x = 2:
(2)² - 5(2) + 6 = 4 - 10 + 6 = 0 ✓

For x = 3:
(3)² - 5(3) + 6 = 9 - 15 + 6 = 0 ✓

**Final Answer:**
The solutions are x = 2 and x = 3.`,
    explanation: `This problem demonstrates the factoring method for solving quadratic equations. The key insight is finding two numbers that multiply to the constant term and add to the linear coefficient. Always verify your solutions by substituting back into the original equation.`,
    is_official: true,
    created_at: "2024-01-15T10:30:00Z",
  },
}

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  // In real app, fetch question data here
  const question = mockQuestion

  if (!question) {
    return {
      title: "Question Not Found",
    }
  }

  return {
    title: `${question.title} - ${question.subject} Class ${question.class_level} | Board Exam Prep`,
    description: `${question.subject} question for Class ${question.class_level} ${question.exam_board} board exam. Difficulty: ${question.difficulty_level}. Marks: ${question.marks}.`,
    keywords: `${question.subject}, Class ${question.class_level}, ${question.exam_board}, ${question.difficulty_level}, board exam, practice question, ${question.tags?.join(", ")}`,
    openGraph: {
      title: question.title,
      description: `${question.subject} - Class ${question.class_level} - ${question.marks} marks`,
      type: "article",
      url: `https://boardexamprep.com/questions/${question.id}`,
    },
    twitter: {
      card: "summary",
      title: question.title,
      description: `${question.subject} - Class ${question.class_level} - ${question.marks} marks`,
    },
    alternates: {
      canonical: `https://boardexamprep.com/questions/${question.id}`,
    },
  }
}

export default function QuestionPage({ params }: { params: { id: string } }) {
  const questionId = params.id

  // In real app, fetch question data here
  const question = mockQuestion

  if (!question) {
    notFound()
  }

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "QAPage",
    mainEntity: {
      "@type": "Question",
      name: question.title,
      text: question.question_text,
      dateCreated: question.created_at,
      author: {
        "@type": "Organization",
        name: "Board Exam Prep",
      },
      acceptedAnswer: {
        "@type": "Answer",
        text: question.answer.answer_text,
        dateCreated: question.answer.created_at,
        author: {
          "@type": "Organization",
          name: "Board Exam Prep",
        },
      },
    },
    about: {
      "@type": "EducationalOccupationalCredential",
      name: `${question.exam_board} Class ${question.class_level} ${question.subject}`,
      educationalLevel: `Class ${question.class_level}`,
      competencyRequired: question.subject,
    },
    educationalLevel: `Class ${question.class_level}`,
    learningResourceType: "Practice Question",
    educationalUse: "assignment",
    audience: {
      "@type": "EducationalAudience",
      educationalRole: "student",
    },
  }

  return (
    <div className="min-h-screen bg-background">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(structuredData),
        }}
      />

      <Navigation />
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Breadcrumb */}
          <Breadcrumb className="mb-6">
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink href="/">Home</BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink href="/questions">Questions</BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage>{question.subject}</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>

          <div className="space-y-8">
            {/* Question Detail */}
            <Suspense fallback={<div>Loading question...</div>}>
              <QuestionDetail question={question} />
            </Suspense>

            {/* Question Actions */}
            <QuestionActions questionId={question.id} />

            {/* Answer Section */}
            <Suspense fallback={<div>Loading answer...</div>}>
              <QuestionAnswer answer={question.answer} />
            </Suspense>

            {/* Comment Discussion Section */}
            <Suspense fallback={<div>Loading comments...</div>}>
              <CommentSection questionId={question.id} answerId={question.answer.id} />
            </Suspense>

            {/* Related Questions */}
            <Suspense fallback={<div>Loading related questions...</div>}>
              <RelatedQuestions
                currentQuestionId={question.id}
                subject={question.subject}
                classLevel={question.class_level}
              />
            </Suspense>
          </div>
        </div>
      </main>
    </div>
  )
}
