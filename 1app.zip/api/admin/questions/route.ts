import { type NextRequest, NextResponse } from "next/server"

// Mock data - in real app this would query the database
const mockQuestions = [
  {
    id: 1,
    title: "Solve the quadratic equation: x² - 5x + 6 = 0",
    question_text: "Solve the quadratic equation: x² - 5x + 6 = 0. Show all steps and verify your answer.",
    subject: "Mathematics",
    class_level: "10",
    exam_board: "CBSE",
    exam_year: 2023,
    difficulty_level: "medium",
    marks: 3,
    created_at: "2024-01-15T10:00:00Z",
    updated_at: "2024-01-15T10:00:00Z",
    is_published: true,
    created_by: 1,
    tags: ["Algebra", "Quadratic Equations"],
    views: 156,
    comments_count: 12,
  },
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const page = Number.parseInt(searchParams.get("page") || "1")
  const limit = Number.parseInt(searchParams.get("limit") || "10")
  const search = searchParams.get("search")
  const subject = searchParams.get("subject")
  const status = searchParams.get("status")

  // Filter questions based on search parameters
  let filteredQuestions = mockQuestions

  if (search) {
    filteredQuestions = filteredQuestions.filter(
      (q) =>
        q.title.toLowerCase().includes(search.toLowerCase()) ||
        q.question_text.toLowerCase().includes(search.toLowerCase()),
    )
  }

  if (subject) {
    filteredQuestions = filteredQuestions.filter((q) => q.subject === subject)
  }

  if (status) {
    const isPublished = status === "published"
    filteredQuestions = filteredQuestions.filter((q) => q.is_published === isPublished)
  }

  // Paginate results
  const startIndex = (page - 1) * limit
  const endIndex = startIndex + limit
  const paginatedQuestions = filteredQuestions.slice(startIndex, endIndex)

  return NextResponse.json({
    questions: paginatedQuestions,
    total: filteredQuestions.length,
    page,
    limit,
    totalPages: Math.ceil(filteredQuestions.length / limit),
  })
}

export async function POST(request: NextRequest) {
  const body = await request.json()

  // Validate required fields
  const requiredFields = [
    "title",
    "question_text",
    "subject",
    "class_level",
    "exam_board",
    "exam_year",
    "difficulty_level",
    "marks",
  ]
  for (const field of requiredFields) {
    if (!body[field]) {
      return NextResponse.json({ error: `Missing required field: ${field}` }, { status: 400 })
    }
  }

  // In real app, save to database
  const newQuestion = {
    id: Date.now(),
    ...body,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    created_by: 1, // Current admin user ID
    views: 0,
    comments_count: 0,
  }

  return NextResponse.json(newQuestion, { status: 201 })
}
