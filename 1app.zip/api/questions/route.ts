import { type NextRequest, NextResponse } from "next/server"

// Mock data - in real app this would query the database
const mockQuestions = [
  {
    id: 1,
    title: "Solve the quadratic equation: x² - 5x + 6 = 0",
    question_text: "Solve the quadratic equation: x² - 5x + 6 = 0. Show all steps and verify your answer.",
    subject: "Mathematics",
    class_level: "10",
    exam_board: "CBSE",
    exam_year: 2023,
    difficulty_level: "medium",
    marks: 3,
    created_at: "2024-01-15T10:00:00Z",
    is_published: true,
  },
  {
    id: 2,
    title: "State and explain Newton's three laws of motion",
    question_text: "State and explain Newton's three laws of motion with real-life examples for each law.",
    subject: "Physics",
    class_level: "11",
    exam_board: "CBSE",
    exam_year: 2023,
    difficulty_level: "medium",
    marks: 5,
    created_at: "2024-01-14T14:30:00Z",
    is_published: true,
  },
  // Add more mock questions as needed
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)

  const query = searchParams.get("q")
  const classLevel = searchParams.get("class")
  const subject = searchParams.get("subject")
  const board = searchParams.get("board")
  const year = searchParams.get("year")
  const difficulty = searchParams.get("difficulty")
  const sortBy = searchParams.get("sort") || "relevance"
  const page = Number.parseInt(searchParams.get("page") || "1")
  const limit = Number.parseInt(searchParams.get("limit") || "10")

  // Filter questions based on search parameters
  const filteredQuestions = mockQuestions.filter((question) => {
    if (
      query &&
      !question.title.toLowerCase().includes(query.toLowerCase()) &&
      !question.question_text.toLowerCase().includes(query.toLowerCase())
    ) {
      return false
    }
    if (classLevel && question.class_level !== classLevel) return false
    if (subject && question.subject !== subject) return false
    if (board && question.exam_board !== board) return false
    if (year && question.exam_year.toString() !== year) return false
    if (difficulty && question.difficulty_level !== difficulty.toLowerCase()) return false

    return question.is_published
  })

  // Sort questions
  switch (sortBy) {
    case "newest":
      filteredQuestions.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      break
    case "oldest":
      filteredQuestions.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
      break
    // Add more sorting options as needed
  }

  // Paginate results
  const startIndex = (page - 1) * limit
  const endIndex = startIndex + limit
  const paginatedQuestions = filteredQuestions.slice(startIndex, endIndex)

  return NextResponse.json({
    questions: paginatedQuestions,
    total: filteredQuestions.length,
    page,
    limit,
    totalPages: Math.ceil(filteredQuestions.length / limit),
  })
}
