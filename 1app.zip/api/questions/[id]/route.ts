import { type NextRequest, NextResponse } from "next/server"

// Mock data - in real app this would query the database
const mockQuestion = {
  id: 1,
  title: "Solve the quadratic equation: x² - 5x + 6 = 0",
  question_text: `Solve the quadratic equation: x² - 5x + 6 = 0. 

Show all steps clearly and verify your answer by substituting back into the original equation.

**Additional Requirements:**
- Use the factoring method
- Show the verification step
- Explain each step of the solution`,
  subject: "Mathematics",
  class_level: "10",
  exam_board: "CBSE",
  exam_year: 2023,
  difficulty_level: "medium",
  marks: 3,
  created_at: "2024-01-15T10:00:00Z",
  updated_at: "2024-01-15T10:00:00Z",
  is_published: true,
  tags: ["Algebra", "Quadratic Equations", "Factoring"],
  answer: {
    id: 1,
    answer_text: `**Solution:**

**Step 1: Identify the quadratic equation**
Given equation: x² - 5x + 6 = 0

**Step 2: Factor the quadratic expression**
We need to find two numbers that:
- Multiply to give +6 (the constant term)
- Add to give -5 (the coefficient of x)

The numbers are -2 and -3 because:
- (-2) × (-3) = +6 ✓
- (-2) + (-3) = -5 ✓

**Step 3: Write in factored form**
x² - 5x + 6 = (x - 2)(x - 3) = 0

**Step 4: Apply the zero product property**
If (x - 2)(x - 3) = 0, then either:
- x - 2 = 0  →  x = 2
- x - 3 = 0  →  x = 3

**Step 5: Verification**
Let's verify both solutions:

For x = 2:
(2)² - 5(2) + 6 = 4 - 10 + 6 = 0 ✓

For x = 3:
(3)² - 5(3) + 6 = 9 - 15 + 6 = 0 ✓

**Final Answer:**
The solutions are x = 2 and x = 3.`,
    explanation: `This problem demonstrates the factoring method for solving quadratic equations. The key insight is finding two numbers that multiply to the constant term and add to the linear coefficient. Always verify your solutions by substituting back into the original equation.`,
    is_official: true,
    created_at: "2024-01-15T10:30:00Z",
  },
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const questionId = Number.parseInt(params.id)

  // In real app, query database for question by ID
  if (questionId === 1) {
    return NextResponse.json(mockQuestion)
  }

  return NextResponse.json({ error: "Question not found" }, { status: 404 })
}
