import { type NextRequest, NextResponse } from "next/server"

// Mock data - in real app this would query the database
const mockComments = [
  {
    id: 1,
    question_id: 1,
    answer_id: 1,
    user_id: 1,
    comment_text:
      "Great explanation! The step-by-step approach really helps understand the factoring method. Could you also show how to solve this using the quadratic formula for comparison?",
    parent_comment_id: null,
    created_at: "2024-01-15T14:30:00Z",
    updated_at: "2024-01-15T14:30:00Z",
    is_helpful: true,
    helpful_count: 12,
    user: {
      id: 1,
      full_name: "Sarah Johnson",
      role: "student",
    },
  },
  {
    id: 2,
    question_id: 1,
    answer_id: 1,
    user_id: 2,
    comment_text:
      "Excellent question, Sarah! Using the quadratic formula: x = (-b ± √(b²-4ac)) / 2a. For x² - 5x + 6 = 0, we have a=1, b=-5, c=6. This gives us x = (5 ± √(25-24)) / 2 = (5 ± 1) / 2, so x = 3 or x = 2. Same result!",
    parent_comment_id: 1,
    created_at: "2024-01-15T15:45:00Z",
    updated_at: "2024-01-15T15:45:00Z",
    is_helpful: true,
    helpful_count: 8,
    user: {
      id: 2,
      full_name: "Mr. Kumar",
      role: "admin",
    },
  },
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const questionId = searchParams.get("question_id")
  const answerId = searchParams.get("answer_id")

  // Filter comments based on question/answer
  const filteredComments = mockComments.filter((comment) => {
    if (questionId && comment.question_id.toString() !== questionId) return false
    if (answerId && comment.answer_id.toString() !== answerId) return false
    return true
  })

  return NextResponse.json({
    comments: filteredComments,
    total: filteredComments.length,
  })
}

export async function POST(request: NextRequest) {
  const body = await request.json()
  const { question_id, answer_id, comment_text, parent_comment_id } = body

  // Validate required fields
  if (!question_id || !comment_text) {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
  }

  // In real app, save to database and return created comment
  const newComment = {
    id: Date.now(),
    question_id: Number.parseInt(question_id),
    answer_id: answer_id ? Number.parseInt(answer_id) : null,
    user_id: 999, // Current user ID
    comment_text,
    parent_comment_id: parent_comment_id ? Number.parseInt(parent_comment_id) : null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    is_helpful: false,
    helpful_count: 0,
    user: {
      id: 999,
      full_name: "Current User",
      role: "student",
    },
  }

  return NextResponse.json(newComment, { status: 201 })
}
