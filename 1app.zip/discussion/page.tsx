import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MessageSquare, TrendingUp, Clock, Search, Filter } from "lucide-react"
import Link from "next/link"

const discussionTopics = [
  {
    id: 1,
    title: "Best strategies for solving quadratic equations",
    category: "Mathematics",
    author: "Sarah Johnson",
    authorRole: "student",
    replies: 24,
    views: 156,
    lastActivity: "2 hours ago",
    isHot: true,
  },
  {
    id: 2,
    title: "Understanding Newton's laws with real-world examples",
    category: "Physics",
    author: "Mr. Kumar",
    authorRole: "teacher",
    replies: 18,
    views: 89,
    lastActivity: "4 hours ago",
    isHot: false,
  },
  {
    id: 3,
    title: "Tips for memorizing chemical equations",
    category: "Chemistry",
    author: "Alex Chen",
    authorRole: "student",
    replies: 12,
    views: 67,
    lastActivity: "6 hours ago",
    isHot: false,
  },
]

export default function DiscussionPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-2">Student Discussions</h1>
            <p className="text-lg text-muted-foreground">
              Connect with fellow students, ask questions, and share knowledge
            </p>
          </div>

          <div className="grid lg:grid-cols-4 gap-8">
            {/* Sidebar */}
            <div className="lg:col-span-1 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Categories</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {["Mathematics", "Physics", "Chemistry", "Biology", "English", "General"].map((category) => (
                    <Button key={category} variant="ghost" className="w-full justify-start text-sm">
                      {category}
                    </Button>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Discussion Stats</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Total Topics</span>
                    <span className="font-medium">1,234</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Active Users</span>
                    <span className="font-medium">456</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Today's Posts</span>
                    <span className="font-medium">89</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3 space-y-6">
              {/* Search and Actions */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input placeholder="Search discussions..." className="pl-10" />
                    </div>
                    <Button variant="outline">
                      <Filter className="h-4 w-4 mr-2" />
                      Filter
                    </Button>
                    <Button>Start Discussion</Button>
                  </div>
                </CardContent>
              </Card>

              {/* Discussion Topics */}
              <div className="space-y-4">
                {discussionTopics.map((topic) => (
                  <Card key={topic.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={`/abstract-geometric-shapes.png?height=40&width=40&query=${topic.author}`} />
                          <AvatarFallback>{topic.author.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 space-y-3">
                          <div className="flex items-start justify-between">
                            <div className="space-y-2">
                              <div className="flex items-center gap-2">
                                {topic.isHot && (
                                  <Badge variant="destructive" className="text-xs">
                                    <TrendingUp className="h-3 w-3 mr-1" />
                                    Hot
                                  </Badge>
                                )}
                                <Badge variant="secondary" className="text-xs">
                                  {topic.category}
                                </Badge>
                              </div>
                              <h3 className="text-lg font-medium text-foreground hover:text-primary cursor-pointer">
                                <Link href={`/discussion/${topic.id}`}>{topic.title}</Link>
                              </h3>
                              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                <span>by {topic.author}</span>
                                <Badge
                                  variant="outline"
                                  className={`text-xs ${topic.authorRole === "teacher" ? "bg-blue-50 text-blue-700" : ""}`}
                                >
                                  {topic.authorRole}
                                </Badge>
                              </div>
                            </div>
                            <div className="text-right text-sm text-muted-foreground">
                              <div className="flex items-center gap-1 mb-1">
                                <Clock className="h-3 w-3" />
                                {topic.lastActivity}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-6 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <MessageSquare className="h-4 w-4" />
                              {topic.replies} replies
                            </div>
                            <div>{topic.views} views</div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Pagination */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-center gap-2">
                    <Button variant="outline" size="sm">
                      Previous
                    </Button>
                    <Button variant="default" size="sm">
                      1
                    </Button>
                    <Button variant="outline" size="sm">
                      2
                    </Button>
                    <Button variant="outline" size="sm">
                      3
                    </Button>
                    <Button variant="outline" size="sm">
                      Next
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
