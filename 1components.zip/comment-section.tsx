"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { MessageSquare, ThumbsUp, ThumbsDown, Reply, Flag, MoreHorizontal } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface Comment {
  id: number
  user: {
    id: number
    name: string
    avatar?: string
    role: "student" | "teacher" | "admin"
  }
  content: string
  createdAt: string
  updatedAt?: string
  helpfulCount: number
  isHelpful: boolean
  userVote?: "up" | "down" | null
  replies: Comment[]
  isEdited: boolean
}

interface CommentSectionProps {
  questionId: number
  answerId: number
}

// Mock data - in real app this would come from API
const mockComments: Comment[] = [
  {
    id: 1,
    user: {
      id: 1,
      name: "Sarah Johnson",
      avatar: "/student-avatar.png",
      role: "student",
    },
    content:
      "Great explanation! The step-by-step approach really helps understand the factoring method. Could you also show how to solve this using the quadratic formula for comparison?",
    createdAt: "2024-01-15T14:30:00Z",
    helpfulCount: 12,
    isHelpful: true,
    userVote: "up",
    isEdited: false,
    replies: [
      {
        id: 2,
        user: {
          id: 2,
          name: "Mr. Kumar",
          avatar: "/teacher-avatar.png",
          role: "teacher",
        },
        content:
          "Excellent question, Sarah! Using the quadratic formula: x = (-b ± √(b²-4ac)) / 2a. For x² - 5x + 6 = 0, we have a=1, b=-5, c=6. This gives us x = (5 ± √(25-24)) / 2 = (5 ± 1) / 2, so x = 3 or x = 2. Same result!",
        createdAt: "2024-01-15T15:45:00Z",
        helpfulCount: 8,
        isHelpful: true,
        userVote: null,
        isEdited: false,
        replies: [],
      },
    ],
  },
  {
    id: 3,
    user: {
      id: 3,
      name: "Alex Chen",
      avatar: "/student-avatar-2.png",
      role: "student",
    },
    content:
      "I'm still confused about how to find the two numbers that multiply to 6 and add to -5. Is there a systematic way to do this?",
    createdAt: "2024-01-15T16:20:00Z",
    helpfulCount: 5,
    isHelpful: false,
    userVote: null,
    isEdited: false,
    replies: [
      {
        id: 4,
        user: {
          id: 1,
          name: "Sarah Johnson",
          avatar: "/student-avatar.png",
          role: "student",
        },
        content:
          "Hi Alex! I list all factor pairs of 6: (1,6), (2,3), (-1,-6), (-2,-3). Then I check which pair adds to -5. Since (-2) + (-3) = -5, that's our answer!",
        createdAt: "2024-01-15T16:35:00Z",
        helpfulCount: 3,
        isHelpful: true,
        userVote: null,
        isEdited: false,
        replies: [],
      },
    ],
  },
]

export function CommentSection({ questionId, answerId }: CommentSectionProps) {
  const [comments, setComments] = useState<Comment[]>(mockComments)
  const [newComment, setNewComment] = useState("")
  const [replyingTo, setReplyingTo] = useState<number | null>(null)
  const [replyContent, setReplyContent] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmitComment = async () => {
    if (!newComment.trim()) return

    setIsSubmitting(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const comment: Comment = {
      id: Date.now(),
      user: {
        id: 999,
        name: "You",
        role: "student",
      },
      content: newComment,
      createdAt: new Date().toISOString(),
      helpfulCount: 0,
      isHelpful: false,
      userVote: null,
      isEdited: false,
      replies: [],
    }

    setComments([...comments, comment])
    setNewComment("")
    setIsSubmitting(false)
  }

  const handleSubmitReply = async (parentId: number) => {
    if (!replyContent.trim()) return

    setIsSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const reply: Comment = {
      id: Date.now(),
      user: {
        id: 999,
        name: "You",
        role: "student",
      },
      content: replyContent,
      createdAt: new Date().toISOString(),
      helpfulCount: 0,
      isHelpful: false,
      userVote: null,
      isEdited: false,
      replies: [],
    }

    setComments(
      comments.map((comment) =>
        comment.id === parentId ? { ...comment, replies: [...comment.replies, reply] } : comment,
      ),
    )

    setReplyContent("")
    setReplyingTo(null)
    setIsSubmitting(false)
  }

  const handleVote = (commentId: number, voteType: "up" | "down") => {
    setComments(
      comments.map((comment) => {
        if (comment.id === commentId) {
          const newVote = comment.userVote === voteType ? null : voteType
          const helpfulDelta = newVote === "up" ? 1 : newVote === "down" ? -1 : comment.userVote === "up" ? -1 : 1
          return {
            ...comment,
            userVote: newVote,
            helpfulCount: Math.max(0, comment.helpfulCount + helpfulDelta),
          }
        }
        return {
          ...comment,
          replies: comment.replies.map((reply) => {
            if (reply.id === commentId) {
              const newVote = reply.userVote === voteType ? null : voteType
              const helpfulDelta = newVote === "up" ? 1 : newVote === "down" ? -1 : reply.userVote === "up" ? -1 : 1
              return {
                ...reply,
                userVote: newVote,
                helpfulCount: Math.max(0, reply.helpfulCount + helpfulDelta),
              }
            }
            return reply
          }),
        }
      }),
    )
  }

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))

    if (diffInHours < 1) return "Just now"
    if (diffInHours < 24) return `${diffInHours}h ago`
    return `${Math.floor(diffInHours / 24)}d ago`
  }

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "teacher":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "admin":
        return "bg-purple-100 text-purple-800 border-purple-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5 text-primary" />
          Discussion ({comments.length + comments.reduce((acc, c) => acc + c.replies.length, 0)})
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Add New Comment */}
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <Avatar className="h-8 w-8">
              <AvatarImage src="/diverse-user-avatars.png" />
              <AvatarFallback>You</AvatarFallback>
            </Avatar>
            <div className="flex-1 space-y-3">
              <Textarea
                placeholder="Share your thoughts, ask questions, or help other students..."
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                className="min-h-[80px] resize-none"
              />
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground">Be respectful and constructive in your discussions</p>
                <Button onClick={handleSubmitComment} disabled={!newComment.trim() || isSubmitting}>
                  {isSubmitting ? "Posting..." : "Post Comment"}
                </Button>
              </div>
            </div>
          </div>
        </div>

        <Separator />

        {/* Comments List */}
        <div className="space-y-6">
          {comments.map((comment) => (
            <div key={comment.id} className="space-y-4">
              {/* Main Comment */}
              <div className="flex items-start gap-3">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={comment.user.avatar || "/placeholder.svg"} />
                  <AvatarFallback>{comment.user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">{comment.user.name}</span>
                    {comment.user.role !== "student" && (
                      <Badge variant="outline" className={`text-xs ${getRoleBadgeColor(comment.user.role)}`}>
                        {comment.user.role}
                      </Badge>
                    )}
                    <span className="text-xs text-muted-foreground">{formatTimeAgo(comment.createdAt)}</span>
                    {comment.isEdited && <span className="text-xs text-muted-foreground">(edited)</span>}
                  </div>
                  <p className="text-sm leading-relaxed">{comment.content}</p>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        className={`h-7 px-2 ${comment.userVote === "up" ? "text-green-600 bg-green-50" : ""}`}
                        onClick={() => handleVote(comment.id, "up")}
                      >
                        <ThumbsUp className="h-3 w-3 mr-1" />
                        {comment.helpfulCount}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className={`h-7 px-2 ${comment.userVote === "down" ? "text-red-600 bg-red-50" : ""}`}
                        onClick={() => handleVote(comment.id, "down")}
                      >
                        <ThumbsDown className="h-3 w-3" />
                      </Button>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 px-2"
                      onClick={() => setReplyingTo(replyingTo === comment.id ? null : comment.id)}
                    >
                      <Reply className="h-3 w-3 mr-1" />
                      Reply
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-7 px-2">
                          <MoreHorizontal className="h-3 w-3" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Flag className="h-4 w-4 mr-2" />
                          Report
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </div>

              {/* Reply Form */}
              {replyingTo === comment.id && (
                <div className="ml-11 space-y-3">
                  <div className="flex items-start gap-3">
                    <Avatar className="h-7 w-7">
                      <AvatarImage src="/diverse-user-avatars.png" />
                      <AvatarFallback className="text-xs">You</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 space-y-2">
                      <Textarea
                        placeholder={`Reply to ${comment.user.name}...`}
                        value={replyContent}
                        onChange={(e) => setReplyContent(e.target.value)}
                        className="min-h-[60px] resize-none text-sm"
                      />
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleSubmitReply(comment.id)}
                          disabled={!replyContent.trim() || isSubmitting}
                        >
                          {isSubmitting ? "Posting..." : "Reply"}
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => setReplyingTo(null)}>
                          Cancel
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Replies */}
              {comment.replies.length > 0 && (
                <div className="ml-11 space-y-4">
                  {comment.replies.map((reply) => (
                    <div key={reply.id} className="flex items-start gap-3">
                      <Avatar className="h-7 w-7">
                        <AvatarImage src={reply.user.avatar || "/placeholder.svg"} />
                        <AvatarFallback className="text-xs">{reply.user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-sm">{reply.user.name}</span>
                          {reply.user.role !== "student" && (
                            <Badge variant="outline" className={`text-xs ${getRoleBadgeColor(reply.user.role)}`}>
                              {reply.user.role}
                            </Badge>
                          )}
                          <span className="text-xs text-muted-foreground">{formatTimeAgo(reply.createdAt)}</span>
                        </div>
                        <p className="text-sm leading-relaxed">{reply.content}</p>
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className={`h-6 px-2 text-xs ${reply.userVote === "up" ? "text-green-600 bg-green-50" : ""}`}
                              onClick={() => handleVote(reply.id, "up")}
                            >
                              <ThumbsUp className="h-3 w-3 mr-1" />
                              {reply.helpfulCount}
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className={`h-6 px-2 text-xs ${reply.userVote === "down" ? "text-red-600 bg-red-50" : ""}`}
                              onClick={() => handleVote(reply.id, "down")}
                            >
                              <ThumbsDown className="h-3 w-3" />
                            </Button>
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-6 px-2">
                                <MoreHorizontal className="h-3 w-3" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <Flag className="h-4 w-4 mr-2" />
                                Report
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Load More Comments */}
        {comments.length > 0 && (
          <div className="text-center pt-4">
            <Button variant="outline">Load More Comments</Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
