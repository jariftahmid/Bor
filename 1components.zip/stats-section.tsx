import { Card, CardContent } from "@/components/ui/card"
import { BookOpen, Users, MessageSquare, Award } from "lucide-react"

const stats = [
  {
    icon: BookOpen,
    value: "5,000+",
    label: "Practice Questions",
    description: "Across all subjects and boards",
  },
  {
    icon: Users,
    value: "10,000+",
    label: "Active Students",
    description: "Learning together daily",
  },
  {
    icon: MessageSquare,
    value: "25,000+",
    label: "Discussions",
    description: "Student interactions and help",
  },
  {
    icon: Award,
    value: "95%",
    label: "Success Rate",
    description: "Students improving their scores",
  },
]

export function StatsSection() {
  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">
              Trusted by Students Nationwide
            </h2>
            <p className="text-lg text-muted-foreground">
              Join thousands of students who have improved their board exam performance
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => {
              const Icon = stat.icon
              return (
                <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mx-auto mb-4">
                      <Icon className="h-8 w-8 text-primary" />
                    </div>
                    <div className="text-3xl font-serif font-bold text-foreground mb-2">{stat.value}</div>
                    <div className="text-lg font-medium text-foreground mb-1">{stat.label}</div>
                    <div className="text-sm text-muted-foreground">{stat.description}</div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
