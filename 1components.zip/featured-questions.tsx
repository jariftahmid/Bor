import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Clock, MessageSquare, BookOpen, ArrowRight } from "lucide-react"

const featuredQuestions = [
  {
    id: 1,
    title: "Quadratic Equations - Factoring Method",
    subject: "Mathematics",
    class: "10",
    board: "CBSE",
    year: "2023",
    difficulty: "Medium",
    marks: 3,
    comments: 12,
    timeAgo: "2 hours ago",
  },
  {
    id: 2,
    title: "Newton's Laws of Motion with Examples",
    subject: "Physics",
    class: "11",
    board: "CBSE",
    year: "2023",
    difficulty: "Medium",
    marks: 5,
    comments: 8,
    timeAgo: "4 hours ago",
  },
  {
    id: 3,
    title: "Photosynthesis Process and Factors",
    subject: "Biology",
    class: "10",
    board: "ICSE",
    year: "2023",
    difficulty: "Hard",
    marks: 8,
    comments: 15,
    timeAgo: "6 hours ago",
  },
]

export function FeaturedQuestions() {
  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-2">Featured Questions</h2>
              <p className="text-lg text-muted-foreground">Recently added questions with detailed solutions</p>
            </div>
            <Button variant="outline">
              View All Questions
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredQuestions.map((question) => (
              <Card key={question.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between mb-2">
                    <Badge variant="secondary" className="text-xs">
                      {question.subject}
                    </Badge>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {question.timeAgo}
                    </div>
                  </div>
                  <CardTitle className="text-lg leading-tight">{question.title}</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex flex-wrap gap-2 mb-4">
                    <Badge variant="outline" className="text-xs">
                      Class {question.class}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {question.board}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {question.year}
                    </Badge>
                    <Badge
                      variant="outline"
                      className={`text-xs ${
                        question.difficulty === "Easy"
                          ? "text-green-600"
                          : question.difficulty === "Medium"
                            ? "text-yellow-600"
                            : "text-red-600"
                      }`}
                    >
                      {question.difficulty}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1">
                        <BookOpen className="h-4 w-4" />
                        {question.marks} marks
                      </div>
                      <div className="flex items-center gap-1">
                        <MessageSquare className="h-4 w-4" />
                        {question.comments}
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" className="text-primary">
                      View Solution
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
