"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Calculator, Atom, Dna, Globe, PenTool, History, MapPin, TrendingUp, Laptop } from "lucide-react"

const classes = [
  { id: "9", label: "Class 9", description: "Foundation concepts" },
  { id: "10", label: "Class 10", description: "Board exam preparation" },
  { id: "11", label: "Class 11", description: "Advanced concepts" },
  { id: "12", label: "Class 12", description: "Final board exams" },
]

const subjects = [
  { id: "mathematics", label: "Mathematics", icon: Calculator, color: "bg-blue-100 text-blue-700" },
  { id: "physics", label: "Physics", icon: Atom, color: "bg-purple-100 text-purple-700" },
  { id: "chemistry", label: "Chemistry", icon: Atom, color: "bg-green-100 text-green-700" },
  { id: "biology", label: "Biology", icon: Dna, color: "bg-emerald-100 text-emerald-700" },
  { id: "english", label: "English", icon: PenTool, color: "bg-orange-100 text-orange-700" },
  { id: "hindi", label: "Hindi", icon: Globe, color: "bg-red-100 text-red-700" },
  { id: "history", label: "History", icon: History, color: "bg-amber-100 text-amber-700" },
  { id: "geography", label: "Geography", icon: MapPin, color: "bg-teal-100 text-teal-700" },
  { id: "economics", label: "Economics", icon: TrendingUp, color: "bg-indigo-100 text-indigo-700" },
  { id: "computer-science", label: "Computer Science", icon: Laptop, color: "bg-gray-100 text-gray-700" },
]

export function ClassSubjectSelector() {
  const [selectedClass, setSelectedClass] = useState<string>("")
  const [selectedSubject, setSelectedSubject] = useState<string>("")

  const handleGetStarted = () => {
    if (selectedClass && selectedSubject) {
      // Navigate to questions page with filters
      window.location.href = `/questions?class=${selectedClass}&subject=${selectedSubject}`
    }
  }

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">Choose Your Study Path</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Select your class and subject to access targeted practice questions and study materials
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-8">
            {/* Class Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-primary" />
                  Select Your Class
                </CardTitle>
                <CardDescription>Choose your current class level</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  {classes.map((classItem) => (
                    <Button
                      key={classItem.id}
                      variant={selectedClass === classItem.id ? "default" : "outline"}
                      className="h-auto p-4 flex flex-col items-start"
                      onClick={() => setSelectedClass(classItem.id)}
                    >
                      <div className="font-semibold">{classItem.label}</div>
                      <div className="text-xs text-muted-foreground">{classItem.description}</div>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Subject Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Atom className="h-5 w-5 text-primary" />
                  Select Your Subject
                </CardTitle>
                <CardDescription>Choose the subject you want to practice</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  {subjects.slice(0, 6).map((subject) => {
                    const Icon = subject.icon
                    return (
                      <Button
                        key={subject.id}
                        variant={selectedSubject === subject.id ? "default" : "outline"}
                        className="h-auto p-3 flex flex-col items-center gap-2"
                        onClick={() => setSelectedSubject(subject.id)}
                      >
                        <Icon className="h-4 w-4" />
                        <span className="text-xs font-medium">{subject.label}</span>
                      </Button>
                    )
                  })}
                </div>
                <div className="mt-4">
                  <Button variant="ghost" size="sm" className="w-full">
                    View All Subjects
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Selection Summary & CTA */}
          {(selectedClass || selectedSubject) && (
            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="text-sm text-muted-foreground">Your Selection:</div>
                    <div className="flex gap-2">
                      {selectedClass && (
                        <Badge variant="secondary">{classes.find((c) => c.id === selectedClass)?.label}</Badge>
                      )}
                      {selectedSubject && (
                        <Badge variant="secondary">{subjects.find((s) => s.id === selectedSubject)?.label}</Badge>
                      )}
                    </div>
                  </div>
                  <Button
                    onClick={handleGetStarted}
                    disabled={!selectedClass || !selectedSubject}
                    className="min-w-[140px]"
                  >
                    Start Practicing
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </section>
  )
}
