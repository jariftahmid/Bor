import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { BookOpen, MessageSquare, ArrowRight } from "lucide-react"
import Link from "next/link"

interface RelatedQuestionsProps {
  currentQuestionId: number
  subject: string
  classLevel: string
}

const mockRelatedQuestions = [
  {
    id: 2,
    title: "Solve using quadratic formula: 2x² + 3x - 5 = 0",
    subject: "Mathematics",
    class: "10",
    difficulty: "Medium",
    marks: 4,
    comments: 8,
  },
  {
    id: 3,
    title: "Find the roots of x² - 7x + 12 = 0 by completing the square",
    subject: "Mathematics",
    class: "10",
    difficulty: "Hard",
    marks: 5,
    comments: 12,
  },
  {
    id: 4,
    title: "Graph the quadratic function y = x² - 4x + 3",
    subject: "Mathematics",
    class: "10",
    difficulty: "Medium",
    marks: 6,
    comments: 15,
  },
]

export function RelatedQuestions({ currentQuestionId, subject, classLevel }: RelatedQuestionsProps) {
  const relatedQuestions = mockRelatedQuestions.filter((q) => q.id !== currentQuestionId)

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case "easy":
        return "text-green-600 bg-green-50 border-green-200"
      case "medium":
        return "text-yellow-600 bg-yellow-50 border-yellow-200"
      case "hard":
        return "text-red-600 bg-red-50 border-red-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-serif">Related Questions</CardTitle>
          <Button variant="outline" size="sm" asChild>
            <Link href={`/questions?subject=${subject}&class=${classLevel}`}>
              View All
              <ArrowRight className="h-4 w-4 ml-1" />
            </Link>
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {relatedQuestions.map((question) => (
            <Card key={question.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="space-y-3">
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary" className="text-xs">
                      {question.subject}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      Class {question.class}
                    </Badge>
                    <Badge variant="outline" className={`text-xs ${getDifficultyColor(question.difficulty)}`}>
                      {question.difficulty}
                    </Badge>
                  </div>

                  <h3 className="font-medium text-foreground leading-tight hover:text-primary cursor-pointer">
                    <Link href={`/questions/${question.id}`}>{question.title}</Link>
                  </h3>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <BookOpen className="h-4 w-4" />
                        {question.marks} marks
                      </div>
                      <div className="flex items-center gap-1">
                        <MessageSquare className="h-4 w-4" />
                        {question.comments} comments
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" asChild>
                      <Link href={`/questions/${question.id}`}>View Solution</Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
