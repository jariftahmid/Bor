import { Button } from "@/components/ui/button"
import { ArrowRight, Users, BookOpen, Trophy } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative py-20 lg:py-32 bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-serif font-bold text-foreground mb-6">
            Master Your Board Exams with <span className="text-primary">Confidence</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
            Access thousands of board exam questions with detailed answers, engage in student discussions, and track
            your progress across all subjects and exam boards.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button size="lg" className="text-base">
              Start Practicing
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button variant="outline" size="lg" className="text-base bg-transparent">
              Browse Questions
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-2xl mx-auto">
            <div className="flex flex-col items-center">
              <div className="flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg mb-3">
                <BookOpen className="h-6 w-6 text-primary" />
              </div>
              <div className="text-2xl font-serif font-bold text-foreground">5,000+</div>
              <div className="text-sm text-muted-foreground">Practice Questions</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg mb-3">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <div className="text-2xl font-serif font-bold text-foreground">10,000+</div>
              <div className="text-sm text-muted-foreground">Active Students</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg mb-3">
                <Trophy className="h-6 w-6 text-primary" />
              </div>
              <div className="text-2xl font-serif font-bold text-foreground">95%</div>
              <div className="text-sm text-muted-foreground">Success Rate</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
