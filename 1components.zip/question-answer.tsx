import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Clock, User } from "lucide-react"

interface Answer {
  id: number
  answer_text: string
  explanation?: string
  is_official: boolean
  created_at: string
}

interface QuestionAnswerProps {
  answer: Answer
}

export function QuestionAnswer({ answer }: QuestionAnswerProps) {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-serif flex items-center gap-2">
            Detailed Solution
            {answer.is_official && (
              <Badge variant="default" className="bg-green-100 text-green-800 border-green-200">
                <CheckCircle className="h-3 w-3 mr-1" />
                Official Answer
              </Badge>
            )}
          </CardTitle>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4" />
            {formatDate(answer.created_at)}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Answer Content */}
        <div className="prose prose-gray max-w-none">
          <div className="text-base leading-relaxed whitespace-pre-wrap">{answer.answer_text}</div>
        </div>

        {/* Explanation */}
        {answer.explanation && (
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-blue-900 flex items-center gap-2">
                <User className="h-5 w-5" />
                Teacher's Note
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-blue-800 leading-relaxed">{answer.explanation}</p>
            </CardContent>
          </Card>
        )}

        {/* Answer Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-border">
          <div className="text-sm text-muted-foreground">Was this answer helpful?</div>
          <div className="flex items-center gap-2">
            <button className="text-sm text-green-600 hover:text-green-700 font-medium">👍 Yes (24)</button>
            <button className="text-sm text-red-600 hover:text-red-700 font-medium">👎 No (2)</button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
