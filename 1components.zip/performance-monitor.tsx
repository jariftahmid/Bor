"use client"

import { useEffect } from "react"

export function PerformanceMonitor() {
  useEffect(() => {
    if (typeof window !== "undefined" && "performance" in window) {
      // Monitor Largest Contentful Paint (LCP)
      new PerformanceObserver((list) => {
        const entries = list.getEntries()
        const lastEntry = entries[entries.length - 1]
        console.log("[v0] LCP:", lastEntry.startTime)
      }).observe({ entryTypes: ["largest-contentful-paint"] })

      // Monitor First Input Delay (FID)
      new PerformanceObserver((list) => {
        const entries = list.getEntries()
        entries.forEach((entry) => {
          console.log("[v0] FID:", entry.processingStart - entry.startTime)
        })
      }).observe({ entryTypes: ["first-input"] })

      // Monitor Cumulative Layout Shift (CLS)
      new PerformanceObserver((list) => {
        const entries = list.getEntries()
        entries.forEach((entry) => {
          if (!entry.hadRecentInput) {
            console.log("[v0] CLS:", entry.value)
          }
        })
      }).observe({ entryTypes: ["layout-shift"] })
    }
  }, [])

  return null
}
