"use client"

import { useSearchParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MessageSquare, BookOpen, Heart, Share2 } from "lucide-react"
import Link from "next/link"

// Mock data - in real app this would come from API
const mockQuestions = [
  {
    id: 1,
    title: "Solve the quadratic equation: x² - 5x + 6 = 0",
    subject: "Mathematics",
    class: "10",
    board: "CBSE",
    year: "2023",
    difficulty: "Medium",
    marks: 3,
    comments: 12,
    likes: 24,
    timeAgo: "2 hours ago",
    excerpt: "Show all steps and verify your answer using the factoring method...",
  },
  {
    id: 2,
    title: "State and explain Newton's three laws of motion with examples",
    subject: "Physics",
    class: "11",
    board: "CBSE",
    year: "2023",
    difficulty: "Medium",
    marks: 5,
    comments: 8,
    likes: 18,
    timeAgo: "4 hours ago",
    excerpt:
      "Provide real-life examples for each law and explain the relationship between force, mass, and acceleration...",
  },
  {
    id: 3,
    title: "Explain the process of photosynthesis in detail",
    subject: "Biology",
    class: "10",
    board: "ICSE",
    year: "2023",
    difficulty: "Hard",
    marks: 8,
    comments: 15,
    likes: 32,
    timeAgo: "6 hours ago",
    excerpt: "Include the chemical equation and factors affecting the rate of photosynthesis...",
  },
  {
    id: 4,
    title: "Analyze the character of Hamlet in Shakespeare's play",
    subject: "English",
    class: "12",
    board: "CBSE",
    year: "2022",
    difficulty: "Hard",
    marks: 10,
    comments: 22,
    likes: 45,
    timeAgo: "1 day ago",
    excerpt: "Discuss his internal conflicts and how they drive the plot forward...",
  },
]

export function QuestionsResults() {
  const searchParams = useSearchParams()
  const sortBy = searchParams.get("sort") || "relevance"

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case "easy":
        return "text-green-600 bg-green-50 border-green-200"
      case "medium":
        return "text-yellow-600 bg-yellow-50 border-yellow-200"
      case "hard":
        return "text-red-600 bg-red-50 border-red-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  return (
    <div className="space-y-6">
      {/* Sort and View Options */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">
              Showing <span className="font-medium text-foreground">1-4</span> of{" "}
              <span className="font-medium text-foreground">1,234</span> questions
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Sort by:</span>
                <Select value={sortBy}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="relevance">Relevance</SelectItem>
                    <SelectItem value="newest">Newest First</SelectItem>
                    <SelectItem value="oldest">Oldest First</SelectItem>
                    <SelectItem value="most-liked">Most Liked</SelectItem>
                    <SelectItem value="most-discussed">Most Discussed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Questions List */}
      <div className="space-y-4">
        {mockQuestions.map((question) => (
          <Card key={question.id} className="hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex flex-wrap gap-2 mb-3">
                    <Badge variant="secondary" className="text-xs">
                      {question.subject}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      Class {question.class}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {question.board}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {question.year}
                    </Badge>
                    <Badge variant="outline" className={`text-xs ${getDifficultyColor(question.difficulty)}`}>
                      {question.difficulty}
                    </Badge>
                  </div>
                  <CardTitle className="text-lg leading-tight mb-2">{question.title}</CardTitle>
                  <p className="text-sm text-muted-foreground line-clamp-2">{question.excerpt}</p>
                </div>
                <div className="text-xs text-muted-foreground whitespace-nowrap">{question.timeAgo}</div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-6 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <BookOpen className="h-4 w-4" />
                    {question.marks} marks
                  </div>
                  <div className="flex items-center gap-1">
                    <MessageSquare className="h-4 w-4" />
                    {question.comments} comments
                  </div>
                  <div className="flex items-center gap-1">
                    <Heart className="h-4 w-4" />
                    {question.likes} likes
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm">
                    <Share2 className="h-4 w-4 mr-1" />
                    Share
                  </Button>
                  <Button size="sm" asChild>
                    <Link href={`/questions/${question.id}`}>View Solution</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Pagination */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <Button variant="outline" disabled>
              Previous
            </Button>
            <div className="flex items-center gap-2">
              <Button variant="default" size="sm">
                1
              </Button>
              <Button variant="outline" size="sm">
                2
              </Button>
              <Button variant="outline" size="sm">
                3
              </Button>
              <span className="text-sm text-muted-foreground">...</span>
              <Button variant="outline" size="sm">
                42
              </Button>
            </div>
            <Button variant="outline">Next</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
