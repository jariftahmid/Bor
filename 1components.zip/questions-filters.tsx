"use client"

import { useRouter, useSearchParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"

const filterOptions = {
  class: [
    { value: "9", label: "Class 9", count: 245 },
    { value: "10", label: "Class 10", count: 432 },
    { value: "11", label: "Class 11", count: 356 },
    { value: "12", label: "Class 12", count: 521 },
  ],
  subject: [
    { value: "Mathematics", label: "Mathematics", count: 387 },
    { value: "Physics", label: "Physics", count: 298 },
    { value: "Chemistry", label: "Chemistry", count: 267 },
    { value: "Biology", label: "Biology", count: 234 },
    { value: "English", label: "English", count: 189 },
    { value: "Hindi", label: "Hindi", count: 156 },
    { value: "History", label: "History", count: 134 },
    { value: "Geography", label: "Geography", count: 123 },
  ],
  board: [
    { value: "CBSE", label: "CBSE", count: 678 },
    { value: "ICSE", label: "ICSE", count: 345 },
    { value: "State Board", label: "State Board", count: 234 },
    { value: "IB", label: "IB", count: 89 },
    { value: "Cambridge", label: "Cambridge", count: 67 },
  ],
  year: [
    { value: "2024", label: "2024", count: 156 },
    { value: "2023", label: "2023", count: 234 },
    { value: "2022", label: "2022", count: 198 },
    { value: "2021", label: "2021", count: 187 },
    { value: "2020", label: "2020", count: 165 },
  ],
  difficulty: [
    { value: "Easy", label: "Easy", count: 423 },
    { value: "Medium", label: "Medium", count: 567 },
    { value: "Hard", label: "Hard", count: 234 },
  ],
}

export function QuestionsFilters() {
  const router = useRouter()
  const searchParams = useSearchParams()

  const updateFilter = (filterType: string, value: string, checked: boolean) => {
    const params = new URLSearchParams(searchParams.toString())

    if (checked) {
      params.set(filterType, value)
    } else {
      params.delete(filterType)
    }

    router.push(`/questions?${params.toString()}`)
  }

  const isFilterActive = (filterType: string, value: string) => {
    return searchParams.get(filterType) === value
  }

  const getActiveFiltersCount = () => {
    return Array.from(searchParams.keys()).filter((key) =>
      ["class", "subject", "board", "year", "difficulty"].includes(key),
    ).length
  }

  const clearAllFilters = () => {
    const params = new URLSearchParams(searchParams.toString())
    ;["class", "subject", "board", "year", "difficulty"].forEach((key) => {
      params.delete(key)
    })
    router.push(`/questions?${params.toString()}`)
  }

  return (
    <Card className="sticky top-24">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Filters</CardTitle>
          {getActiveFiltersCount() > 0 && <Badge variant="secondary">{getActiveFiltersCount()}</Badge>}
        </div>
        {getActiveFiltersCount() > 0 && (
          <Button variant="ghost" size="sm" onClick={clearAllFilters} className="w-full">
            Clear All Filters
          </Button>
        )}
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Class Filter */}
        <div>
          <h3 className="font-medium text-foreground mb-3">Class</h3>
          <div className="space-y-2">
            {filterOptions.class.map((option) => (
              <div key={option.value} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={`class-${option.value}`}
                    checked={isFilterActive("class", option.value)}
                    onCheckedChange={(checked) => updateFilter("class", option.value, checked as boolean)}
                  />
                  <label
                    htmlFor={`class-${option.value}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    {option.label}
                  </label>
                </div>
                <span className="text-xs text-muted-foreground">{option.count}</span>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Subject Filter */}
        <div>
          <h3 className="font-medium text-foreground mb-3">Subject</h3>
          <div className="space-y-2">
            {filterOptions.subject.map((option) => (
              <div key={option.value} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={`subject-${option.value}`}
                    checked={isFilterActive("subject", option.value)}
                    onCheckedChange={(checked) => updateFilter("subject", option.value, checked as boolean)}
                  />
                  <label
                    htmlFor={`subject-${option.value}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    {option.label}
                  </label>
                </div>
                <span className="text-xs text-muted-foreground">{option.count}</span>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Board Filter */}
        <div>
          <h3 className="font-medium text-foreground mb-3">Exam Board</h3>
          <div className="space-y-2">
            {filterOptions.board.map((option) => (
              <div key={option.value} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={`board-${option.value}`}
                    checked={isFilterActive("board", option.value)}
                    onCheckedChange={(checked) => updateFilter("board", option.value, checked as boolean)}
                  />
                  <label
                    htmlFor={`board-${option.value}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    {option.label}
                  </label>
                </div>
                <span className="text-xs text-muted-foreground">{option.count}</span>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Year Filter */}
        <div>
          <h3 className="font-medium text-foreground mb-3">Year</h3>
          <div className="space-y-2">
            {filterOptions.year.map((option) => (
              <div key={option.value} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={`year-${option.value}`}
                    checked={isFilterActive("year", option.value)}
                    onCheckedChange={(checked) => updateFilter("year", option.value, checked as boolean)}
                  />
                  <label
                    htmlFor={`year-${option.value}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    {option.label}
                  </label>
                </div>
                <span className="text-xs text-muted-foreground">{option.count}</span>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Difficulty Filter */}
        <div>
          <h3 className="font-medium text-foreground mb-3">Difficulty</h3>
          <div className="space-y-2">
            {filterOptions.difficulty.map((option) => (
              <div key={option.value} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={`difficulty-${option.value}`}
                    checked={isFilterActive("difficulty", option.value)}
                    onCheckedChange={(checked) => updateFilter("difficulty", option.value, checked as boolean)}
                  />
                  <label
                    htmlFor={`difficulty-${option.value}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    {option.label}
                  </label>
                </div>
                <span className="text-xs text-muted-foreground">{option.count}</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
