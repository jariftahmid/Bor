"use client"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  LayoutDashboard,
  BookOpen,
  Users,
  MessageSquare,
  Settings,
  BarChart3,
  FileText,
  Shield,
  Upload,
} from "lucide-react"

const sidebarItems = [
  {
    title: "Dashboard",
    href: "/admin",
    icon: LayoutDashboard,
  },
  {
    title: "Questions",
    href: "/admin/questions",
    icon: BookOpen,
    badge: "1,234",
  },
  {
    title: "Users",
    href: "/admin/users",
    icon: Users,
    badge: "5,678",
  },
  {
    title: "Comments",
    href: "/admin/comments",
    icon: MessageSquare,
    badge: "12",
  },
  {
    title: "Analytics",
    href: "/admin/analytics",
    icon: BarChart3,
  },
  {
    title: "Content",
    href: "/admin/content",
    icon: FileText,
  },
  {
    title: "Import/Export",
    href: "/admin/import-export",
    icon: Upload,
  },
  {
    title: "Moderation",
    href: "/admin/moderation",
    icon: Shield,
    badge: "3",
  },
  {
    title: "Settings",
    href: "/admin/settings",
    icon: Settings,
  },
]

export function AdminSidebar() {
  const pathname = usePathname()

  return (
    <div className="w-64 bg-card border-r border-border h-screen sticky top-0">
      <div className="p-6">
        <h2 className="text-lg font-serif font-bold text-foreground">Admin Panel</h2>
        <p className="text-sm text-muted-foreground">Content Management</p>
      </div>
      <nav className="px-4 space-y-2">
        {sidebarItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href

          return (
            <Link key={item.href} href={item.href}>
              <Button variant={isActive ? "default" : "ghost"} className="w-full justify-start" size="sm">
                <Icon className="h-4 w-4 mr-3" />
                {item.title}
                {item.badge && (
                  <Badge variant="secondary" className="ml-auto text-xs">
                    {item.badge}
                  </Badge>
                )}
              </Button>
            </Link>
          )
        })}
      </nav>
    </div>
  )
}
