"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Search, X, Filter } from "lucide-react"

export function QuestionsSearch() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [searchQuery, setSearchQuery] = useState(searchParams.get("q") || "")
  const [showMobileFilters, setShowMobileFilters] = useState(false)

  // Get active filters from URL
  const activeFilters = [
    searchParams.get("class") && { key: "class", value: `Class ${searchParams.get("class")}` },
    searchParams.get("subject") && { key: "subject", value: searchParams.get("subject") },
    searchParams.get("board") && { key: "board", value: searchParams.get("board") },
    searchParams.get("year") && { key: "year", value: searchParams.get("year") },
    searchParams.get("difficulty") && { key: "difficulty", value: searchParams.get("difficulty") },
  ].filter(Boolean)

  const handleSearch = (query: string) => {
    const params = new URLSearchParams(searchParams.toString())
    if (query.trim()) {
      params.set("q", query.trim())
    } else {
      params.delete("q")
    }
    router.push(`/questions?${params.toString()}`)
  }

  const removeFilter = (filterKey: string) => {
    const params = new URLSearchParams(searchParams.toString())
    params.delete(filterKey)
    router.push(`/questions?${params.toString()}`)
  }

  const clearAllFilters = () => {
    router.push("/questions")
  }

  useEffect(() => {
    setSearchQuery(searchParams.get("q") || "")
  }, [searchParams])

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-4">
          {/* Search Input */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search questions, topics, or keywords..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch(searchQuery)}
                className="pl-10"
              />
            </div>
            <Button onClick={() => handleSearch(searchQuery)}>Search</Button>
            <Button
              variant="outline"
              size="icon"
              className="lg:hidden bg-transparent"
              onClick={() => setShowMobileFilters(!showMobileFilters)}
            >
              <Filter className="h-4 w-4" />
            </Button>
          </div>

          {/* Active Filters */}
          {activeFilters.length > 0 && (
            <div className="flex flex-wrap gap-2 items-center">
              <span className="text-sm text-muted-foreground">Filters:</span>
              {activeFilters.map((filter) => (
                <Badge key={filter.key} variant="secondary" className="flex items-center gap-1">
                  {filter.value}
                  <button
                    onClick={() => removeFilter(filter.key)}
                    className="ml-1 hover:bg-muted-foreground/20 rounded-full p-0.5"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
              <Button variant="ghost" size="sm" onClick={clearAllFilters}>
                Clear all
              </Button>
            </div>
          )}

          {/* Results Summary */}
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <span>Showing results for your search</span>
            <span>Found 1,234 questions</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
