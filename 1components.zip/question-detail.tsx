import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, BookOpen, Award, Tag } from "lucide-react"

interface Question {
  id: number
  title: string
  question_text: string
  subject: string
  class_level: string
  exam_board: string
  exam_year: number
  difficulty_level: string
  marks: number
  created_at: string
  tags?: string[]
}

interface QuestionDetailProps {
  question: Question
}

export function QuestionDetail({ question }: QuestionDetailProps) {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case "easy":
        return "bg-green-100 text-green-800 border-green-200"
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "hard":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-wrap gap-2 mb-4">
          <Badge variant="default" className="bg-primary text-primary-foreground">
            {question.subject}
          </Badge>
          <Badge variant="outline">Class {question.class_level}</Badge>
          <Badge variant="outline">{question.exam_board}</Badge>
          <Badge variant="outline">{question.exam_year}</Badge>
          <Badge variant="outline" className={getDifficultyColor(question.difficulty_level)}>
            {question.difficulty_level.charAt(0).toUpperCase() + question.difficulty_level.slice(1)}
          </Badge>
        </div>
        <CardTitle className="text-2xl md:text-3xl font-serif leading-tight">{question.title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Question Metadata */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-muted/50 rounded-lg">
          <div className="flex items-center gap-2 text-sm">
            <BookOpen className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">{question.marks}</span>
            <span className="text-muted-foreground">marks</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Award className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">{question.difficulty_level}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">{question.exam_year}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">{formatDate(question.created_at)}</span>
          </div>
        </div>

        {/* Question Text */}
        <div className="prose prose-gray max-w-none">
          <div className="text-lg leading-relaxed whitespace-pre-wrap">{question.question_text}</div>
        </div>

        {/* Tags */}
        {question.tags && question.tags.length > 0 && (
          <div className="flex items-center gap-2 flex-wrap">
            <Tag className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Tags:</span>
            {question.tags.map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
